
public class ArrayDemo3 {

	public static void main(String[] args) {
		int arr[][]= {
				{1,2,3},
				{100,200,300,400,500},
				{11,22,33,44,55,66,77,88},
				{51,52,53,54}
		};
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.printf("Element at %d:%d is %d\n",i,j, arr[i][j]);
			}
		}
	}

}
