
public class StringDemo2 {

	public static void main(String[] args) {
		int i=20;
		int j=30;
		float f=1.299f;
		float k=f+j;
		
		System.out.format("The sum of %2.2f and %d is %f\n",f,j,k);
		//but this formatted output should be stored in a String variable
		String result=String.format("The sum of %2.2f and %d is %f\n",f,j,k);
		System.out.println(result);
	}

}
