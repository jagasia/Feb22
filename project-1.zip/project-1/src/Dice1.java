import java.util.Scanner;

public class Dice1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		if(a<0 || a>6 || b<0 || b>6)
		{	
			System.out.println("Invalid Input");
			System.exit(0); 				//return also is fine to stop main method
		}
		if(a!=b)
            System.out.println("The point scored is" + (a+b));
        else
            System.out.println("The point scored is" + (2*(a+b)));	}

}
