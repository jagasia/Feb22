import java.util.Scanner;

public class Dice2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		if(a<0 || a>6 || b<0 || b>6)
		{	
			System.out.println("Invalid Input");
			System.exit(0); 				//return also is fine to stop main method
		}
		int sum=a+b;
		int points=Math.abs(8-sum);
		if(sum>=8)
		{			
			//the point  scored is double the absolute difference between 8 and the sum of the 2 values
			points=2*points;
		}
		System.out.println("The points scored is "+points);
	}

}
