
public class ForDemo {

	public static void main(String[] args) {
		int y = 20;
		int z = 100;
		int arr[]= {4,10,2,22,44,3,4,99,9,7};
		for(int x:arr)
			System.out.println(x);
	}

}
