
public class ArrayDemo2 {

	public static void main(String args[]) {
		int arr[][]=new int[10][];
		
		//why second dimension is missing???
		//imagine a 2 dimension array as an array or arrays
		arr[0]=new int[10];
		arr[1]=new int[15];
		arr[2]=new int[5];
		arr[4]=new int[100];
		//here a 2 dimensional array has every row having different size of columns
		//THIS IS CALLED AS JAGGED ARRAY
		System.out.println(arr[0].length);
		System.out.println(arr[1].length);
		System.out.println(arr[2].length);
	}

}
