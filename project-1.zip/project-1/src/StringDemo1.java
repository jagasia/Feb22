class A
{
	
}

class B
{
	
}

class C
{
	
}
class StringDemo1 {

	public static void main(String[] args) {
		int x=2;
		int y=3;
//		System.out.println("answer is "+x+y); 			//what is the output
		///	how to convert a number into String
		
//		String str=x+"";				//x is a number how to convert it into string
		String str=String.valueOf(x);			//correct way to convert int to String
		
		
		char c='a';					//char variables can contain only 1 character
		c='\0';						//				\0 is null
		c='\n';						//				\n is new line		\t is for tab
		
		//how will u store '				character inside a char variable?
//		c=''';								//doesn't work
		c='\'';								//			\' is a '
		
		//how will you store \		as a character in char
		c='\\';
		
	}

}