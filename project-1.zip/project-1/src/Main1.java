
public class Main1 {

	public static void main(String[] args) {
//		byte age=127;
//		age++;
//		System.out.println(age);
		
//		short x=32767;			//max
//		x++;
//		System.out.println(x);
		
//		int y=2147483647;
//		y++;
//		System.out.println(y);
//		System.out.println(Long.MAX_VALUE);
//		long z=9223372036854775807L;
//		z++;
//		System.out.println(z);
		
		int x=20;
		System.out.println(x!=20);
	}
}