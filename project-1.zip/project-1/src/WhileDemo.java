
public class WhileDemo {

	public static void main(String[] args) {
		
		for(int i=20,j=10;i<25;++i)
		{
			System.out.println(i);
		}
	}
}
