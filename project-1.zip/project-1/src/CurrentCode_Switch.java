import java.util.Scanner;

public class CurrentCode_Switch {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		String result="";
		switch(input)
		{
		case "INR":
			result="India";
			break;
		case "USD":
			result="USA";
			break;
		case "EUR":
			result="Europe";
			break;
		default:
			result="Unknown code";
		}
		System.out.println(result);
	}

}
