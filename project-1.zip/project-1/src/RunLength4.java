import java.util.Scanner;


public class RunLength4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		//got n inputs and stored in the array .....
		
		//walk through the array once
		int evenCount=0;
		int largestRunSequence=0;
		int startIndex=-1;
		int largestStartIndex=-1;
		for(int i=0;i<n;i++)
		{
			if(arr[i]%2==0)		//check even number
			{
				//increase even count
				evenCount++;
				if(evenCount==1)
					startIndex=i;
				if(evenCount>largestRunSequence)
				{
					largestRunSequence=evenCount;
					largestStartIndex=startIndex;
				}
			}
			else
			{
				//means, odd number  is found
				evenCount=0;
			}
//			System.out.println("Even count is:"+evenCount);
//			System.out.println("Largest run seq:"+largestRunSequence);
//			System.out.println("start index:"+startIndex+" and largest index is "+largestStartIndex);
			
		}
		System.out.println(largestRunSequence);
		System.out.println(largestStartIndex);
	}

}
