import java.util.Scanner;

public class IntroductoryAlgebra1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		//-555
		if(Math.abs(a)<10 || Math.abs(a)>99 || Math.abs(b)<10 || Math.abs(b)>99)
		{
			System.out.println("Invalid Input");
			return;					//System.exit(0)		is also fine
		}
		//continue if valid input
		if(a<0 ^ b<0)
		{
			System.out.println("Correct");
		}
		else
			System.out.println("Incorrect");
	}

}
