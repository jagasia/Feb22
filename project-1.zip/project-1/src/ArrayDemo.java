
public class ArrayDemo {
	public static void main(String[] args) {
		int arr[]= {22,6,1088,911,34,2220,100,4};
		//find max value in this array
		int largest=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>largest)
				largest=arr[i];		//no else part
		//	System.out.println(arr[i]);
		}
		System.out.println(largest);
	}
}
