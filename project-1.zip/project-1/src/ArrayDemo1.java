
public class ArrayDemo1 {
	public static void main(String[] args) {
		int arr[]=new int[10];
		System.out.println(arr.length);
		arr[0]=122;
		System.out.println("Before: "+arr[0]);
		arr=new int[20];				//NOTICE "new" operator here. It will create new array
		System.out.println("After: "+arr[0]);
		System.out.println(arr.length);
		//arr is stack variable. new int[] creates array in heap. its reference is stored in arr(stack)
		//
	
	}
}
